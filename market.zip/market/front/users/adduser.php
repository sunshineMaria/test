<body bgcolor="eeeeee">
<head>
<link rel="stylesheet" href="../../css/admin/adduser.css">	
</head>
<h1 align="center">ע��</h1>
<?php
session_start();
?>
<div class="content">
<form name="adduser" action="dealadduser.php" method="post">
<label>�û���</label><input type="text" name="username" /><br/><br/>
<label>����</label><input type="password" name="password" /><br/><br/>
<label>�绰����</label><input type="text" name="phone" /><br/><br/>
<label>��ַ</label><input type="text" name="address" /><br/><br/>
<input class="btn" type="submit" value="����" />&nbsp;&nbsp;
<input class="btn" type="reset" value="��д" />
</form>
</div>
</body>