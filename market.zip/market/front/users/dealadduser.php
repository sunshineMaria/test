<?php

include_once("../../db/db.php");

$username=$_POST["username"];
$password=$_POST["password"];
$phone=$_POST["phone"];
$address=$_POST["address"];

mysql_query('set names gb2312');
$sql="insert into `user` values(null,'$username','$password','��ͨ�û�','$phone','$address');";



mysql_query($sql);
echo"<script> alert('ע��ɹ���'); </script>";
echo"<script> location.href='adduser.php'; </script>";

mysql_close();


?>
