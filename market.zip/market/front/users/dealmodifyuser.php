<?php
session_start();
include_once("../../db/db.php");
$username=$_SESSION["username"];
$password=$_POST["password"];
$phone=$_POST["phone"];
$address=$_POST["address"];

mysql_query('set names gb2312');
$sql="update `user` set `password`='$password',`phone`='$phone',`address`='$address' where `username`='$username' ";


if(mysql_query($sql)){
  	echo"<script> alert('�޸ĳɹ���'); </script>";
	
	}else
{
echo"<script> alert('�޸�ʧ�ܣ�'); </script>";
	echo"<script> location.href='modifyuser.php'; </script>";
}
mysql_close();

?>