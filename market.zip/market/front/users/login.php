<html>
<head>
	<link rel="stylesheet" href="../../css/front/login.css">
</head>
<body>
	<div class="login">
		<div class="title">��¼</div>
		<div class="content">
			<form name="login" action="deallogin.php" method="post">
			<label>�û���</label><input type="text" name="username"/><br/><br/>
			<label>����</label><input type="password" name="password"/><br/><br/>
			<input class="btn" type="submit" value="��¼"/>&nbsp;&nbsp;
			<input class="btn" type="reset" value="����"/>
		</div>
	</div>
</body>
</html>