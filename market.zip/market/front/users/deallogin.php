

<?php

session_start();
include_once("../../db/db.php");
$username = $_POST["username"];
$password = $_POST["password"];
mysql_query('set names gb2312');
$sql="select * from `user` where username='$username' and password='$password'";
$result=mysql_query($sql);
$num = mysql_num_rows($result);
echo"<script> alert($result); </script>";
if($num>=1){
$_SESSION["username"]=$username;

echo"<script> alert('��¼�ɹ���'); </script>";

echo"<script> location.href='../goods/listgoods.php'; </script>";
echo "<script  type='text/javascript'>window.parent.frames[menu].location.reload(); </script>"; 
echo "<script   type='text/javascript'>window.parent.frames[main].location.reload();</script>  ";

}
else
{
echo"<script> alert('��¼ʧ�ܣ�'); </script>";
echo"<script> location.href='login.php'; </script>";
}

mysql_close();
?>