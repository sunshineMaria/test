<html>
<head>
	<link rel="stylesheet" href="../../css/admin/modifyuser.css">
</head>
<body>

<?php
session_start();
include_once("../../db/db.php");


@$username=$_SESSION['username'];


$sql="select * from `user` where `username` = '$username'";
$result=mysql_query($sql);
if($array = mysql_fetch_array($result)){
$phone=$array["phone"];
$address=$array["address"];
}




?>
<h1>�޸��û���Ϣ</h1>
<div class="content">
<form name="modifyuser" action="dealmodifyuser.php"  method="post">
<label>�û���</label><input type="text" name="username"  value="<?php if(isset($_SESSION['username'])) {echo $username;} ?>"/><br/><br/>
<label>������</label><input type="password" name="password" /><br/><br/>
<label>�绰����</label><input type="text" name="phone" value="<?php if(isset($_SESSION['username'])) {echo $phone; }?>" /><br/><br/>
<label>��ַ</label><input type="text" name="address" value="<?php if(isset($_SESSION['username'])) {echo $address; }?>" /><br/><br/>
<input class="btn" type="submit" value="����" />&nbsp;&nbsp;
<input class="btn" type="reset" value="��д" />
<form/>
</div>

</center>

</body>
</form>


