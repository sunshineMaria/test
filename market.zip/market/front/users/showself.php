<body bgcolor="#eeeeee">
<center>
<?php
session_start();
$username=$_SESSION["username"];
include_once "../../db/db.php";
$sql ="select * from `user` where username='$username'";
$result=mysql_query($sql);
echo "<table>";
if($array=mysql_fetch_array($result)){
echo "<tr><td>�û���:</td><td>$username</td></tr> 
<tr><td>��ϵ��ʽ:</td><td>$array[phone]</td></tr>
<tr><td>��ϵ��ַ:</td><td>$array[address]</td></tr></table>";
}
mysql_close();
?>
</center>
</body>