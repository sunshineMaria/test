<?php
session_start();
include_once "../../db/db.php";
$username=$_SESSION["username"];
$goodid=$_POST["goodid"];
$remark=$_POST["remark"];

$result=mysql_query("select * from `user` where `username`='$username' ");
$array = mysql_fetch_array($result);
$userid= $array["id"];
date_default_timezone_set('prc');
$fbtime= date('y-m-d h:i:s',time());

$sql="insert into remark(`id`,`remark`,`username`,`goodid`,`remarktime`) values(null,'$remark','$username','$goodid','$fbtime')";

if(mysql_query($sql)){
echo"<script> alert('���۳ɹ���'); </script>";
echo"<script> location.href='listgoods.php'; </script>";

}else{
echo"<script> alert('����ʧ�ܣ�'); </script>";
echo"<script> location.href='listgoods.php'; </script>";

}



mysql_close();
?>