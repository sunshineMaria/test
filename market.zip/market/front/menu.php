<html>
<head>
	<link rel="stylesheet" href="../css/front/menu.css">
</head>
<body>
<h1>�����г�</h1>
<h2>��Ʒ����</h2><br/>
<p class="addgoods"><img src="../image/add.png" alt="addgoods">
<a href="goods/useraddgoods.php" target="main">������Ʒ</a>
</p>
<p class="goodslist"><img src="../image/goodslist.png" alt="goodslist">
<a href="goods/listgoods.php" target="main">��Ʒ�б�</a>
</p>
<br>
<h2>��������</h2><br/>
<?php 
session_start();
if(! isset($_SESSION["username"])){
echo "<p class='login'><img src='../image/login.png' alt='login'>
<a href='users/login.php' target='main'>��¼</a></p>";

}else{
echo "<a href='users/showself.php' target='main'>$_SESSION[username]</a>";


}
?>
<p class="addusr"><img src="../image/adduser.png" alt="adduser">
<a href="users/adduser.php" target="main">ע��</a>
</p>
<p class="modifyuser"><img src="../image/modify.png" alt="modify">
<a href="users/modifyuser.php" target="main">�޸�����</a>
</p>
<?php
if(isset($_SESSION["username"])){
echo "<a href='users/login.php' target='main' style='color:#000000'><h3>�����ʺ�</h3></a>";


}
?>
</body>
</html>