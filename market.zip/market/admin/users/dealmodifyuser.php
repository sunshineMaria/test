<?php

include_once("../../db/db.php");
$id=$_POST["id"];
$username=$_POST["username"];
$password=$_POST["password"];
$phone=$_POST["phone"];
$address=$_POST["address"];

$sql="update `user` set `password`='$password',`phone`='$phone',`address`='$address' where id='$id' ;";

if(mysql_query($sql)){
  	echo"<script> alert('�޸ĳɹ���'); </script>";
	echo"<script> location.href='listusers.php'; </script>";
	}else
{
echo"<script> alert('�޸�ʧ�ܣ�'); </script>";
	echo"<script> location.href='modifyuser.php'; </script>";
}
mysql_close();

?>