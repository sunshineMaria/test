<html>
<head>
	<link rel="stylesheet" href="../../css/admin/listusers.css">
</head>
<body bgcolor="eeeeee">
<h1 align="center">�û��б�</h1>
<table border="1" align = "center" cellspacing="0" cellpadding="0">
<tr>
<th width=100 height=40>id</th>
<th width=100 height=40>�û���</th>
<th width=100 height=40>��ϵ��ʽ</th>
<th width=100 height=40>�û���ַ</th>
<th width=100 height=40>�޸�����</th>
<th width=100 height=40>ɾ���û�</th>
</tr>
<?php
include_once "../../db/db.php";

mysql_query('set names gb2312');
$sql="select * from `user` where label='����Ա'";
$result=mysql_query($sql);
while($array = mysql_fetch_array($result) ){
echo "<tr>
<td height=40>$array[id]</td>
<td height=40>$array[username]</td>
<td height=40>$array[phone]</td>
<td height=40>$array[address]</td>
<td height=40><a href='modifyuser.php?id=$array[id]'>�޸�</a></td>
<td height=40><a href='delusers.php?id=$array[id]'>ɾ���û�</a></td>

      </tr>";

}
mysql_close();

?>
</table>
</body>
</html>