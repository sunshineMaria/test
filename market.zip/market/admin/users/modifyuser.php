<?php

include_once("../../db/db.php");

$id=$_GET["id"];

mysql_query('set names gb2312');
$sql="select * from `user` where `id`='$id'";
$result = mysql_query($sql);
if($array = mysql_fetch_array($result)){
$phone=$array["phone"];
$address=$array["address"];
}


mysql_close();


?>
<html>
<head>
	<link rel="stylesheet" href="../../css/admin/modifyuser.css">
</head>
<body>
<h1>�޸��û���Ϣ</h1>
<div class="content">
<form name="modifyuser" action="dealmodifyuser.php"  method="post">
<label>�û���</label><input type="text" name="username"  value="<?php echo $array["username"]; ?>"/><br/><br/>
<label>������</label><input type="password" name="password" /><br/><br/>
<label>�绰����</label><input type="text" name="phone" value="<?php echo $phone; ?>" /><br/><br/>
<label>��ַ</label><input type="text" name="address" value="<?php echo $address; ?>" /><br/><br/>
<input class="btn" type="submit" value="����" />&nbsp;&nbsp;
<input class="btn" type="reset" value="��д" />
<input type="hidden" value="<?php echo $id; ?>" name="id" />
<form/>
</div>
</body>
</html>



