<?php

include_once("../../db/db.php");

$id=$_GET["id"];


mysql_query('set names gb2312');
$sql="delete from `user` where `id`='$id'";



mysql_query($sql);
echo"<script> alert('ɾ���ɹ���'); </script>";
echo"<script> location.href='listusers.php'; </script>";

mysql_close();


?>