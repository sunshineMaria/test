<?php
session_start();
include_once("../db/db.php");
$username = $_POST["username"];
$password = $_POST["password"]; 
mysql_query('set names gb2312');
$sql="select * from `user` where username='$username' and password='$password' and label='����Ա'";
$result=mysql_query($sql);
$num = mysql_num_rows($result);
if($num>=1){
$_SESSION["admin"]=$username;
echo"<script> alert('��¼�ɹ���'); </script>";
echo"<script> location.href='index.php'; </script>";


}
else
{
echo"<script> alert('��¼ʧ�ܣ�'); </script>";
echo"<script> location.href='login.php'; </script>";
}

mysql_close();
?>