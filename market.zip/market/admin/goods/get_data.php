<?php 
include_once "../../db/db.php";
if(isset($_GET['id'])) { 
$id = $_GET['id'];

$query = "select * from goods where id=$id"; 
$result = mysql_query($query); 
 
$out=mysql_fetch_array($result);
$data=$out["image"];

 
Header( "Content-type: image/jpeg"); 
echo $data; 
}

?>