<?php
include_once "../../db/db.php";
$title=$_POST["title"];
$content=$_POST["content"];
$fbname=$_POST["fbname"];
$price=$_POST["price"];
@$id=$_POST["id"];
@$label=$_POST["label"];
@$imgfile=$_FILES['imgfile'];


if(is_array($imgfile)){
 $name=$imgfile['name'];  
 $type=$imgfile['type']; 
  $size=$imgfile['size'];  
 $tmpfile=$imgfile['tmp_name'];  

if($label!=null&& $tmpfile){
 $file=fopen($tmpfile,"rb");
  $imgdata=bin2hex(fread($file,$size)); 
  fclose($file);




mysql_query('set names gb2312');
$sql="update `goods` set `title`='".$title."',`content`='".$content."',`fbname`='".$fbname."' ,`price`='".$price."',`label`='".$label."',`image`=0x".$imgdata."  where id=$id;";
   
	if(mysql_query($sql)){
  	echo"<script> alert('�޸ĳɹ���'); </script>";
	echo"<script> location.href='listgoods.php'; </script>";
	}
	else{
 	echo "<center>�޸�ʧ��1��<br><br><a href='listgoods.php'>�����޸�</a></center>";
	}
	mysql_close();
}else{
echo "<center>�޸�ʧ��2��<br><br><a href='listgoods.php'>�����޸�</a></center>";
}

}else{
echo"<script> alert('�޸�ʧ��3��'); </script>";
echo"<script> location.href='listgoods.php'; </script>";
}

?>