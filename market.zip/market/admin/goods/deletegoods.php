<?php

include_once("../../db/db.php");

$id=$_GET["id"];


$sql="delete from `goods` where `id`='$id'";



mysql_query($sql);
echo"<script> alert('ɾ���ɹ���'); </script>";
echo"<script> location.href='listgoods.php'; </script>";

mysql_close();


?>