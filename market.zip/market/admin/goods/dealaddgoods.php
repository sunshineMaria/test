<html>

<body  bgcolor="eeeeee">

<?php
include_once "../../db/db.php";
session_start();
$title=$_POST['title'];
$content=$_POST['content'];
$price=$_POST['price'];
@$label=$_POST["label"];
$fbname=$_SESSION["admin"];
date_default_timezone_set('prc');
$fbtime= date('y-m-d h:i:s',time());
$imgfile=$_FILES['imgfile'];
 $submitbtn=$_POST['submitbtn'];
 if($submitbtn=='OK' and is_array($imgfile)){
 $name=$imgfile['name'];  
 $type=$imgfile['type']; 
  $size=$imgfile['size'];  
 $tmpfile=$imgfile['tmp_name'];  
  if($tmpfile and is_uploaded_file($tmpfile)&&$title!=null&&$content!=null&&$price!=null&&$label!=null){ 
  $file=fopen($tmpfile,"rb");
  $imgdata=bin2hex(fread($file,$size)); 
  fclose($file);
 

mysql_query('set names gb2312');
  if(mysql_query("insert into goods(title,content,image,label,price,fbname,fbtime,status) values('".$title."','".$content."',0x".$imgdata.",'".$label."','".$price."','".$fbname."','".$fbtime."','�����')"))
   echo "<center>�ύ�ɹ���<br><br><a href='listgoods.php'>������Ʒ�б�</a></center>";
  else
   echo "<center>����ʧ�ܣ�</center>";
  mysql_close();
 }else
 echo "<center>��Ϣ���벻������<br><br><a href='addgoods.php'>��˷���</a></center>";
} else
 echo "<center>����ѡ��ͼƬ��<br><br><a href='addgoods.php'>��˷���</a></center>";
?>
</body>
</html>