<html>
<h1 align="center">�޸���Ʒ��Ϣ</h1>
</html>
<?php

include_once("../../db/db.php");

$id=$_GET["id"];


$sql="select * from `goods` where `id`='$id'";
mysql_query('set names gb2312');
$result = mysql_query($sql);
$arrn=mysql_fetch_array($result);

mysql_close();


?>
<form name="modifygoods" action="dealmodifygoods.php"  method="post" enctype="multipart/form-data">
<input type="hidden" value="204800" name="MAX_FILE_SIZE"/>
<table border=1 >
<tr><td>��Ʒ���ƣ�</td><td><input type="text" name="title"  value="<?php echo $arrn["title"]; ?>"  /></td></tr>
<td>
  ����ǩ��
</td>
<td>
<input type="radio" name="label" value="����"/> ����
	<input type="radio"   name="label" value="�鼮"/>�鼮
	<input type="radio"   name="label" value="�·�"/>�·�
	<input type="radio" name="label" value="ʳƷ"/>ʳƷ
	<input type="radio" name="label" value="����"/>����
	<input type="radio" name="label" value="����"/>����
 </td>
</tr>
<tr><td>��Ʒ������</td><td><textarea name="content"  rows="10" cols="100"> <?php echo $arrn["content"]; ?> </textarea></td></tr>
<tr><td>��Ʒ�۸�</td><td><input type="text" name="price"  value="<?php echo $arrn["price"]; ?>"  /></td></tr>
<tr><td>�����ߣ�</td><td><input type="text" name="fbname"  value="<?php echo $arrn["fbname"]; ?>" /></td></tr>
<tr> <td>��ƷͼƬ��</td><td><input type="file" name="imgfile" /></td></tr>
</table>
</br>
<input type="submit" value="����"  name="submitbt"/>&nbsp;&nbsp;

<input type="reset" value="��д" />
<input type="hidden" value="<?php echo $id; ?>" name="id" />
<form/>


