<html>
	<head>
		<link rel="stylesheet" href="../../css/admin/listgoods.css">
	</head>
	<body>
		<h1 align="center">��Ʒ�б�</h1>
		<div class="search">
		<form action="listgoods.php">
		�������ǩ��ѯ��
			<input type="radio" name="label" value="ȫ��"/>ȫ��
			<input type="radio" name="label" value="����"/> ����
			<input type="radio" name="label" value="�鼮"/>�鼮
			<input type="radio" name="label" value="�·�"/>�·�
			<input type="radio" name="label" value="ʳƷ"/>ʳƷ
			<input type="radio" name="label" value="����"/>����
			<input type="radio" name="label" value="����"/>����
			<input class="searchbtn" type="submit" value="��ѯ" />
		</div>
		<div class="content">
		<table class="info" align="center" cellspacing="0" cellpadding="0"> 
			<th width=180 height=40>��ƷͼƬ</th>
			<th width=180 height=40>��Ʒ����</th>
			<th width=180 height=40>��Ʒ����</th>
			<th width=180 height=40>��Ʒ״̬</th>
			<th width=180 height=40>����ʱ��</th>
			<th width=180 height=40>����</th>
<?php
include_once "../../db/db.php";
mysql_query('set names gb2312');
@$label=$_GET["label"];

if($label==null||$label=='ȫ��'){
 $result=mysql_query("select * from `goods`  ");


}
 else{
$label=$_GET["label"];
  $result=mysql_query("select * from `goods` where `label`='$label' ");
}

$nums=mysql_num_rows($result);

if(isset($_GET["page"])){

   $page = $_GET['page'];



}
else{

   $page = 1;

} 


$pagesize=5;
$pages=(int)($nums/$pagesize)+1;

if($page<1){$page=1;}
if($page>$pages){$page=$pages; }
$kaishi=($page-1)*$pagesize;


if($label==null||$label=='ȫ��')
 $result=mysql_query("select * from `goods`  order by id desc limit $kaishi,$pagesize ");
 else
  $result=mysql_query("select * from `goods` where `label`='$label'  order by id desc limit $kaishi,$pagesize");

while($array = mysql_fetch_array($result)){
 
 echo "<tr>

<td height=100><a href='goodsinfo.php?id=$array[id]'><img style='style:height:100px;width:130px;' src='get_data.php?id=".$array['id']."'  /></a></td>
<td><a class='name' href='goodsinfo.php?id=$array[id]'>$array[title]</a></td>
<td>$array[content]</td>
<td>$array[status]</td>
<td>$array[fbtime]</td>
<td><a class='operation' href='deletegoods.php?id=$array[id]'>ɾ��</a>

<a class='operation' href='modifygoods.php?id=$array[id]'>�޸�</a>

</td>
</tr>";

}
echo "</table></div>";

 mysql_close();
?>
<html>
<div class="page">
<a href="?page=1&label=<?php echo $label;?>">��ҳ</a> <a href="?page=<?php echo $page-1;?>&label=<?php echo $label;?>">��ҳ</a> ��ǰ��<?php echo $page;?>ҳ <a href="?page=<?php echo $page+1;?>&label=<?php echo $label;?>">��ҳ</a> <a href="?page=<?php echo $pages;?>&label=<?php echo $label;?>">βҳ</a>
</div>
</html>


</body>