<?php 
session_start();
if(! isset($_SESSION["admin"])){
echo"<script> alert('���ȵ�¼��'); </script>";
echo"<script> location.href='login.php'; </script>";

}
?>
<html>
  <head>
    <title>��̨����</title>
  </head>
    <frameset cols="14%,*" frameborder="0">
      <frame src="menu.php" name="menu">
      <frame src="main.php" name="main" >
    </frameset>
 
</html>
